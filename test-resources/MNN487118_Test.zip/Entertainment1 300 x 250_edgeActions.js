/***********************
* Adobe Edge Animate Composition Actions
*
* Edit this file with caution, being careful to preserve 
* function signatures and comments starting with 'Edge' to maintain the 
* ability to interact with these actions from within Adobe Edge Animate
*
***********************/
(function($, Edge, compId){
var Composition = Edge.Composition, Symbol = Edge.Symbol; // aliases for commonly used Edge classes

   //Edge symbol: 'stage'
   (function(symbolName) {
      
      
      

      Symbol.bindElementAction(compId, symbolName, "${Button}", "click", function(sym, e) {
         function getQueryStringValue(key) {
         	return unescape(window.location.search.replace(
         		new RegExp("^(?:.*[&\\?]"
         		+ escape(key).replace(/[\.\+\*]/g, "\\$&")
         		+ "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
         }

         var clickUrl = sym.$("w2txt_1_1_4_clickthru").text();
         var trackingUrl = getQueryStringValue("trackurl");
         
         // Open in a new window
         window.open(trackingUrl + clickUrl, "_blank");

      });
      //Edge binding end

   })("stage");
   //Edge symbol end:'stage'

})(window.jQuery || AdobeEdge.$, AdobeEdge, "EDGE-15010519");