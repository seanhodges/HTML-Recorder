/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'Rectangle',
                            type: 'rect',
                            rect: ['0px', '0px', '300px', '250px', 'auto', 'auto'],
                            opacity: '1',
                            fill: ["rgba(255,255,255,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'w2img_1_1_2_Pic1',
                            type: 'image',
                            rect: ['0px', '151px', '300px', '100px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"w2img_1_1_2-89dca251-501a-4836-b2a5-eb2c340708b2",'0px','0px']
                        },
                        {
                            id: 'Background2',
                            type: 'image',
                            rect: ['0px', '64px', '300px', '172px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"Background.png",'0px','0px']
                        },
                        {
                            id: 'Ellipse',
                            type: 'ellipse',
                            rect: ['264px', '162px', '13px', '13px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            fill: ["rgba(204,51,51,1)"],
                            stroke: [1,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Ellipse2',
                            type: 'ellipse',
                            rect: ['278px', '169px', '43px', '43px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            fill: ["rgba(255,102,0,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'w2img_1_1_1_Logo',
                            type: 'image',
                            rect: ['228px', '15px', '80px', '40px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"w2img_1_1_1-bf106f55-4017-4466-99e1-bcec3a2ba863",'0px','0px']
                        },
                        {
                            id: 'w2txt_1_1_1_Heading',
                            type: 'text',
                            rect: ['304px', '10px', '200px', '44px', 'auto', 'auto'],
                            opacity: '0',
                            text: "WEST ANGLIA COUNTRY SHOW",
                            align: "center",
                            font: ['Arial, Helvetica, sans-serif', [16, ""], "rgba(108,1,1,1.00)", "400", "none", "", "break-word", "normal"],
                            textStyle: ["0px", "", "18px", "", ""]
                        },
                        {
                            id: 'w2txt_1_1_2_SubHeading',
                            type: 'text',
                            rect: ['298px', '79px', '286px', '26px', 'auto', 'auto'],
                            opacity: '0',
                            text: "Masses to see and do!",
                            align: "center",
                            font: ['Arial, Helvetica, sans-serif', [16, ""], "rgba(0,0,0,1.00)", "400", "none solid rgb(255, 255, 255)", "normal", "break-word", ""],
                            textStyle: ["", "", "18px", "", ""]
                        },
                        {
                            id: 'Rectangle2',
                            type: 'rect',
                            rect: ['101px', '117px', '100px', '25px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(204,51,51,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'w2txt_1_1_3_CallToAction',
                            type: 'text',
                            rect: ['101px', '121px', '100px', '22px', 'auto', 'auto'],
                            opacity: '0',
                            text: "Book Tickets",
                            align: "center",
                            font: ['Arial, Helvetica, sans-serif', [14, ""], "rgba(255,255,255,1)", "600", "none solid rgb(255, 255, 255)", "normal", "break-word", ""],
                            textStyle: ["", "", "16px", "", ""]
                        },
                        {
                            id: 'w2txt_1_1_4_clickthru',
                            type: 'text',
                            rect: ['0px', '0px', '300px', '250px', 'auto', 'auto'],
                            opacity: '0',
                            text: "http://www.oakleighfairs.co.uk/wgcs/",
                            align: "center",
                            font: ['Georgia, Times New Roman, Times, serif', [13, ""], "rgba(255,255,255,1)", "600", "none solid rgb(255, 255, 255)", "normal", "break-word", "normal"]
                        },
                        {
                            id: 'Border',
                            type: 'rect',
                            rect: ['0px', '0px', '298px', '248px', 'auto', 'auto'],
                            fill: ["rgba(128,152,74,0.00)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Button',
                            type: 'rect',
                            rect: ['0px', '0px', '300px', '250px', 'auto', 'auto'],
                            cursor: 'pointer',
                            fill: ["rgba(192,192,192,0.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '300px', '250px', 'auto', 'auto'],
                            overflow: 'hidden',
                            fill: ["rgba(255,255,255,1)"]
                        }
                    }
                },
                timeline: {
                    duration: 4500,
                    autoPlay: true,
                    data: [
                        [
                            "eid126",
                            "left",
                            3500,
                            1000,
                            "swing",
                            "${Rectangle2}",
                            '308px',
                            '101px'
                        ],
                        [
                            "eid112",
                            "left",
                            0,
                            1000,
                            "easeOutQuad",
                            "${w2img_1_1_1_Logo}",
                            '228px',
                            '8px'
                        ],
                        [
                            "eid120",
                            "left",
                            2000,
                            1500,
                            "swing",
                            "${w2txt_1_1_2_SubHeading}",
                            '298px',
                            '8px'
                        ],
                        [
                            "eid116",
                            "left",
                            1000,
                            1000,
                            "swing",
                            "${w2txt_1_1_1_Heading}",
                            '304px',
                            '94px'
                        ],
                        [
                            "eid114",
                            "opacity",
                            0,
                            1000,
                            "easeOutQuad",
                            "${w2img_1_1_1_Logo}",
                            '0',
                            '1'
                        ],
                        [
                            "eid128",
                            "opacity",
                            3500,
                            1000,
                            "swing",
                            "${w2txt_1_1_3_CallToAction}",
                            '0',
                            '1'
                        ],
                        [
                            "eid124",
                            "left",
                            3500,
                            1000,
                            "swing",
                            "${w2txt_1_1_3_CallToAction}",
                            '313px',
                            '101px'
                        ],
                        [
                            "eid122",
                            "opacity",
                            2000,
                            1500,
                            "swing",
                            "${w2txt_1_1_2_SubHeading}",
                            '0',
                            '1'
                        ],
                        [
                            "eid118",
                            "opacity",
                            1000,
                            1000,
                            "swing",
                            "${w2txt_1_1_1_Heading}",
                            '0',
                            '1'
                        ],
                        [
                            "eid130",
                            "opacity",
                            3500,
                            1000,
                            "swing",
                            "${Rectangle2}",
                            '0',
                            '1'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("Entertainment1%20300%20x%20250_edgeActions.js");
})("EDGE-15010519");
